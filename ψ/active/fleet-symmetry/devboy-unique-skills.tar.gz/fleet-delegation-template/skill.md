---
name: fleet-delegation-template
description: "Fleet task delegation with 6-part template, debt register logging, and Layer 3 verification checklists. Use when delegating tasks to BOYs (FORGEBOY, LEDGERBOY, WIREBOY, CHATBOY, COACHBOY), assigning work to agents, creating delegation prompts, or verifying completed work. Also use when logging technical debt or running verification checklists. Triggers: delegate, task BOY, assign work, delegation template, tech debt, debt register, verify done, layer 3, verification checklist."
---

# Fleet Delegation Template

## 6-Part Delegation Template (MANDATORY for every BOY task)

```
1. OBJECTIVE
   What to build/do. Include Definition of Done.
   Example: "Build Data Center v6 page at /data-center route. Done = builds clean, matches reference design."

2. OUTPUT FORMAT
   How to structure the deliverable.
   Example: "Single page.tsx file in app/data-center/, React + TypeScript + Tailwind."

3. TOOLS
   Which tools/APIs/repos to use.
   Example: "Read reference at ψ/active/data-center-v6-approved.html. Build in jera-ssot-cloud project."

4. BOUNDARIES
   What NOT to do.
   Example: "Do NOT modify existing pages. Do NOT install new dependencies. Do NOT change visual design."

5. REFERENCE DATA (CRITICAL — never let agents guess)
   Actual data, file paths, credentials location.
   Example: "Reference HTML: 2216 lines at [path]. Use existing Tailwind config. Follow layout.tsx patterns."

6. EXCEPTIONS (CRITICAL — 67% bug rate without this)
   Domain edge cases, business rules, known gotchas.
   Example: "Thai text may contain zero-width spaces. GENCODE 'OPD' includes both walk-in and appointment."
```

## Technical Debt Register

When any BOY says "I'll fix this later" or you notice something deferred:

```markdown
## Technical Debt Register

| # | Item | Impact | Source | Date | Status |
|---|------|--------|--------|------|--------|
| 1 | [what] | [H/M/L] | [which session] | [date] | open |
```

**Rules:**
- Log NOW, not after session
- Every 2 feature sessions → 1 cleanup session
- Weekly scan checks register
- Location: each BOY's CLAUDE.md → Technical Debt Register section

## Layer 3 Verification Checklist

Before declaring ANY work done, verify all 3 layers:

### Layer 1 — Structure (automated, ~30s)
- [ ] Does it build? (`npm run build` / `bun build`)
- [ ] Do existing tests pass?
- [ ] No TypeScript errors?
- [ ] Imports correct?

### Layer 2 — Content (manual, ~2-5 min)
- [ ] Data is real (not placeholder/mock)?
- [ ] Domain rules respected?
- [ ] Component integrated (imported, routed, navigable)?
- [ ] No conflicts with existing features?

### Layer 3 — Reality (end-to-end, ~2-5 min)
- [ ] Can a human use this? (open browser, click through)
- [ ] Does it solve the stated business problem?
- [ ] Would Captain approve this quality?

**"Build passes" = Layer 1 only = NOT DONE.**

## GLUEBOY Delegation Checklist

Before sending task to BOY:
1. [ ] Run gate-2-pre-check (does this exist? right repo? business problem stated?)
2. [ ] Classify TIER (T1/T2/T3 — see below). Use lowest tier sufficient.
3. [ ] Fill all 6 parts of delegation template
4. [ ] Include REFERENCE DATA — never let BOY guess file locations
5. [ ] Include EXCEPTIONS — domain edge cases
6. [ ] Append HEARTBEAT CONTRACT to prompt (mandatory for T2+)
7. [ ] Specify: commit + push when done
8. [ ] Specify: report completion status to GLUEBOY

---

## 3-Tier Delegation Classification (Wind/Oracle 101 ch07)

**Use the lowest tier sufficient for the job.** Over-engineering small tasks adds overhead without value.

### T1 — Arrows (~5 min, fast)
- Read/summarize tasks, single-shot lookup, "scan this and tell me X"
- No worktree, no TaskList, no heartbeat
- Just `maw hey <boy> "<question>"` and wait
- **When to use:** "What's the latest in CoachBoy retros?" / "Summarize this Sheet"

### T2 — Squads (5-30 min, structured)
- Multi-step implementation, code changes, file creation
- Worktree-isolated, TaskList tracked, heartbeat REQUIRED
- Single specialist BOY OR coordinated 2-3 BOYs
- **When to use:** "Build feature X in repo Y" / "Audit BOY repos for pattern"

### T3 — Federation (long-running, session-critical)
- Multi-hour or multi-session work, must survive crash
- Separate tmux session, periodic checkpoints, formal handoff
- Heartbeat + parking + resume discipline
- **When to use:** "Migrate 12K customers" / "Reindex full corpus" / Cross-machine sync

---

## Heartbeat Contract (MANDATORY for T2+)

Append this verbatim to every T2/T3 delegation prompt:

```
REPORTING CONTRACT (mandatory):
- Every 5 min:  maw hey glueboy "[<BOYNAME>] PROGRESS: <one-line status>"
- If blocked:   maw hey glueboy "[<BOYNAME>] STUCK: <reason + evidence>"
- When done:    maw hey glueboy "[<BOYNAME>] DONE: <PR/branch/file path>"

If silent >30 min → GLUEBOY auto-escalates (assume STUCK).
Override only if explicitly told "no heartbeat needed" by GLUEBOY.
```

**Why:** Silent failures are the hardest fleet bugs to find. 5-min cadence = detect within 30 min (Wind's Oracle 101 ch07 threshold).

---

## Lifecycle Discipline (`maw done` enforcement)

After every task completes (T2/T3):
1. BOY runs `maw pr` (if applicable) to open PR
2. Captain/GLUEBOY reviews + approves merge
3. After merge: **BOY MUST run `maw done <window>`** — closes window, commits ψ memory, runs /rrr, cleans worktree
4. Skipping `maw done` = "trace incomplete" = work NOT counted as finished

Per Wind/Oracle 101 ch08: *"Cycle ends only when trace is complete: request → branch → PR → QA → merge → deploy → maw done → memory recorded"*
