---
name: bye
description: Detach from the current tmux session — session keeps running, you drop back to your shell. Fleet-wide convenience for the many-BOYs workflow.
---

# /bye

Wave goodbye + `tmux detach-client`. Session stays alive on the host; reattach later with `tmux attach -t <session>`.

## Usage

```
/bye             # detach with default farewell
/bye <message>   # detach with custom farewell line
```

## Step 1: Identify yourself

Read `CLAUDE.md` to find this BOY's name + emoji (e.g. IOTBOY 🔭, MLBOY 🔥⚗️, GLUEBOY 🔮). If CLAUDE.md isn't present or doesn't have an obvious identity, fall back to the tmux session name from `tmux display-message -p '#S'`.

## Step 2: Print farewell

Single line, BOY-signed, informative:

```
🔭 IOTBOY signing off — session 11-iotboy stays warm. Reattach: tmux attach -t 11-iotboy
```

If `<message>` was passed as argument, include it before the reattach hint.

## Step 3: Detach

```bash
tmux detach-client
```

That's it. The current tmux client disconnects, Captain's terminal returns to the parent shell. Claude session keeps running on the host — context warm, allowlists intact, MCP servers still connected.

## Notes

- **Don't `kill`** — that ends the session. We only detach.
- **No commit** — `/bye` is a session-end gesture, not a save. If you have uncommitted work, that's on you (the BOY) to decide before invoking.
- **Reattach** is the inverse: `tmux attach -t <session>` from any shell on the host. Multiple clients can attach simultaneously (mirror mode); detaching one doesn't affect others.
- **If not in tmux**: `tmux detach-client` errors out cleanly. The farewell still prints. No harm.

## Why a skill (vs `Ctrl-B d`)

`Ctrl-B d` is faster — two keypresses vs typing `/bye`. Use `/bye` when:
- You want a logged farewell in Claude's transcript (audit trail of "I left at HH:MM")
- You want a custom message (`/bye "back after dinner"`)
- Muscle memory prefers slash-commands over tmux prefix

For pure speed, `Ctrl-B d` wins. Both work, both leave the session running.
